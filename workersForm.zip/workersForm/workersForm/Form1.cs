﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workersForm
{
    public partial class Form1 : Form
    {
        string connectionString = "server=LAPTOP-41C9ESQI\\SQLEXPRESS; initial catalog =time_clock_YD9;user id=sa; password = 1234";
        SqlConnection sqlConnection;
        public Form1()
        {

            InitializeComponent();
        }

        bool connect()
        {
            try
            {
                sqlConnection = new SqlConnection(connectionString);
                sqlConnection.Open();
                MessageBox.Show("Success");
                return true;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.ToString());
                return false;
            }
            
        }

        private void IdLabel_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // sql query declaration as a string
            string text = "declare  @worker_code int, @answer varchar(100)\r\nselect @worker_code = (SELECT code from workers where id = @id)\r\n--check if id doesnt exist\r\nif @worker_code IS NULL\r\n\tbegin\r\n\t\tSelect @answer = 'username or password incorrect'\r\n\tend\r\nelse\r\n\tbegin\r\n\tif not exists(SELECT code from passwords where worker_code=@worker_code AND password = @password AND validate = 1)\r\n\t\tbegin\r\n\t\t\tSelect @answer = 'username or password incorrect'\r\n\t\tend\r\n\telse\r\n\t\tbegin\r\n\t\t--check if worker going entering or leaving work\r\n\t\tif exists(SELECT code from time where exit_time IS NULL and worker_code = @worker_code)\r\n\t\t\tbegin\r\n\t\t\t\tupdate time set exit_time = GETDATE() where worker_code = @worker_code AND exit_time is null\r\n\t\t\t\tSELECT @answer = 'exit time ' + CONVERT(varchar(10), getdate(), 103) + ' ' + CONVERT(varchar(10), getdate(), 108)\r\n\t\t\tend\r\n\t\telse \r\n\t\t\tbegin\r\n\t\t\tinsert into time VALUES(@worker_code, getdate(), null)\r\n\t\t\tSELECT @answer = 'entry time ' + CONVERT(varchar(10), getdate(), 103) + ' ' + CONVERT(varchar(10), getdate(), 108)\r\n\t\t\tend\r\n\t\tend\r\n\tend\r\nSELECT @answer";
            //open sql server connection
            if (!connect()) return;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlConnection; // open connection
            cmd.CommandText = text; // sql query
            cmd.Parameters.AddWithValue("@id", txtID.Text);
            cmd.Parameters.AddWithValue("@password", txtPass.Text);
            MessageBox.Show(cmd.ExecuteScalar().ToString());
            sqlConnection.Close();
        }

        private void passbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void passbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            // check if return button is pressed (enter)
            if (e.KeyChar != Convert.ToChar(Keys.Return))
                return;
            MessageBox.Show("Enter pressed");
            button1_Click(sender, e);

                


        }

        private void button2_Click(object sender, EventArgs e)
        {
            string id = txtID.Text;
            while(id == "")
            {
                id = Microsoft.VisualBasic.Interaction.InputBox("Enter id","password change");
            }
            Form2 form2form = new Form2(connectionString,id);
            form2form.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            connect();
        }
    }
}

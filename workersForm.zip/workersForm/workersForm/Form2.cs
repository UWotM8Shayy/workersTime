﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace workersForm
{
   
    public partial class Form2 : Form
    {
        string ConnectionString;
        public Form2(string connectionString, string id)
        {
            InitializeComponent();
            ConnectionString = connectionString;
            idlbl.Text = id;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string text = "declare @worker_code int,\r\n@answer varchar(100)\r\n\r\nSELECT @worker_code = (SELECT code from workers where id = @id)\r\nif @worker_code IS NULL\r\nbegin\r\n\tSELECT @answer = 'id incorrect'\r\nend\r\nelse\r\nbegin \r\n\tif not exists(SELECT code FROM passwords where password = @old_password AND worker_code = @worker_code AND validate = 1)\r\n\tbegin\r\n\t\tSELECT @answer = 'password incorrect' \r\n\tend\r\n\telse\r\n\tbegin \r\n\t\tif exists(SELECT code FROM passwords WHERE code = @worker_code AND password = @new_password)\r\n\t\tbegin\r\n\t\t\tSELECT @answer = 'new password cant be same old password'\r\n\t\tend\r\n\t\telse\r\n\t\tbegin\r\n\t\t\tupdate passwords SET validate = 0 WHERE code = @worker_code\r\n\t\t\tINSERT INTO passwords VALUES(@worker_code, @new_password,GETDATE() + 180,1)\r\n\t\t\tSELECT @answer = 'password reset successfully, expiry date is in 180 days'\r\n\r\n\t\tend\r\n\tend\r\nend\r\n\r\nSELECT @answer\r\n";
            using (SqlConnection newSqlConnection = new SqlConnection(ConnectionString))
            {
                try
                {
                    newSqlConnection.Open();
                    using (SqlCommand cmd = new SqlCommand(text, newSqlConnection))
                    {
                        cmd.Parameters.AddWithValue("@id", idlbl.Text);
                        cmd.Parameters.AddWithValue("@old_Password", txtOldPass.Text);
                        cmd.Parameters.AddWithValue("@new_Password", txtNewPass.Text);
                        MessageBox.Show($"Debug: ID = {idlbl.Text}, Old Password = {txtOldPass.Text}, New Password = {txtNewPass.Text}");

                        object result = cmd.ExecuteScalar();
                        if (result != null)
                        {
                            MessageBox.Show(result.ToString());
                        }
                        else
                        {
                            MessageBox.Show("No result returned.");
                        }
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
        }



    }
}
